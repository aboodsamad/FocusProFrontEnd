import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:stomp_dart_client/stomp_dart_client.dart';
import '../../../core/constants/app_colors.dart';
import '../../../features/home/providers/user_provider.dart';
import '../models/focus_room.dart';
import '../services/focus_room_service.dart';
import 'package:flutter/foundation.dart';

class FocusRoomSessionPage extends StatefulWidget {
  final FocusRoom room;
  const FocusRoomSessionPage({Key? key, required this.room}) : super(key: key);

  @override
  State<FocusRoomSessionPage> createState() => _FocusRoomSessionPageState();
}

class _FocusRoomSessionPageState extends State<FocusRoomSessionPage> {
  StompClient? _stompClient;
  List<RoomMember> _members = [];
  bool _connecting = true;
  String? _error;
  String? _myGoal;

  // Session timer
  late final Stopwatch _stopwatch;
  late final Timer _ticker;
  String _elapsed = '00:00';

  @override
  void initState() {
    super.initState();
    _stopwatch = Stopwatch()..start();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) {
        setState(() {
          final d = _stopwatch.elapsed;
          _elapsed = '${d.inMinutes.toString().padLeft(2, '0')}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';
        });
      }
    });
    _askGoalThenConnect();
  }

@override
void dispose() {
  _ticker.cancel();
  _stopwatch.stop();
  _pollTimer?.cancel();
  // Leave the room on exit
  if (kIsWeb) {
    FocusRoomService.leaveRoomRest(widget.room.id);
  } else if (_stompClient != null) {
    FocusRoomService.sendLeave(_stompClient!, widget.room.id);
    Future.delayed(const Duration(milliseconds: 300),
        () => _stompClient?.deactivate());
  }
  super.dispose();
}

  Future<void> _askGoalThenConnect() async {
    final goalCtl = TextEditingController();
    String? goal;

    try {
      goal = await showDialog<String>(
        context: context,
        barrierDismissible: false,
        builder: (_) => AlertDialog(
          backgroundColor: const Color(0xFF0F1624),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Row(
            children: [
              Text(widget.room.emoji, style: const TextStyle(fontSize: 24)),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  widget.room.name,
                  style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('What are you working on?', style: TextStyle(color: Colors.grey[400], fontSize: 13)),
              const SizedBox(height: 12),
              TextField(
                controller: goalCtl,
                style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(
                  hintText: 'e.g. Finishing chapter 3 (optional)',
                  hintStyle: TextStyle(color: Colors.grey[600], fontSize: 13),
                  filled: true,
                  fillColor: Colors.white.withOpacity(0.06),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, ''),
              child: Text('Skip', style: TextStyle(color: Colors.grey[500])),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryA,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              onPressed: () => Navigator.pop(context, goalCtl.text.trim()),
              child: const Text('Join Room'),
            ),
          ],
        ),
      );
    } catch (e) {
      if (mounted) Navigator.pop(context);
      return;
    }

    if (!mounted) return;

    // Empty string means Skip was tapped, null means dialog was dismissed
    if (goal == null) {
      Navigator.pop(context);
      return;
    }

    _myGoal = goal.isNotEmpty ? goal : null;
    _connectWebSocket();
  }

  Future<void> _connectWebSocket() async {
    if (!mounted) return;

    // On web, WebSocket to localhost is blocked by the browser.
    // Use polling instead — fetch members every 3 seconds.
    if (kIsWeb) {
      _startPolling();
      return;
    }

    try {
      final client = await FocusRoomService.connect(
        roomId: widget.room.id,
        goal: _myGoal,
        onEvent: (event) {
          if (mounted) setState(() => _members = event.members);
        },
        onError: (err) {
          if (mounted)
            setState(() {
              _error = 'WebSocket: $err';
              _connecting = false;
            });
        },
      );
      if (!mounted) {
        client.deactivate();
        return;
      }
      _stompClient = client;
      setState(() => _connecting = false);
    } catch (e) {
      if (mounted)
        setState(() {
          _error = 'Connection failed: $e';
          _connecting = false;
        });
    }
  }

  Timer? _pollTimer;

  void _startPolling() async {
    // First call: join via REST so we appear in the room
    try {
      await FocusRoomService.joinRoomRest(widget.room.id, _myGoal);
    } catch (_) {}

    if (mounted) setState(() => _connecting = false);

    // Then poll every 3 seconds to refresh member list
    _pollTimer = Timer.periodic(const Duration(seconds: 3), (_) async {
      try {
        final room = await FocusRoomService.getRoom(widget.room.id);
        if (mounted) setState(() => _members = room.members);
      } catch (_) {}
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF080D1A),
      body: SafeArea(
        child: Column(
          children: [
            _buildHeader(),
            if (_connecting) _buildConnecting(),
            if (_error != null) _buildError(),
            if (!_connecting && _error == null) Expanded(child: _buildContent()),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.06),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.white.withOpacity(0.08)),
              ),
              child: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white70, size: 16),
            ),
          ),
          const SizedBox(width: 12),
          Text(widget.room.emoji, style: const TextStyle(fontSize: 22)),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              widget.room.name,
              style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.bold),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          // Session timer
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: AppColors.primaryA.withOpacity(0.12),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.primaryA.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                const Icon(Icons.timer_outlined, color: AppColors.primaryA, size: 14),
                const SizedBox(width: 4),
                Text(
                  _elapsed,
                  style: const TextStyle(color: AppColors.primaryA, fontWeight: FontWeight.bold, fontSize: 13),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildConnecting() {
    return const Expanded(
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(color: AppColors.primaryA),
            SizedBox(height: 16),
            Text('Joining room...', style: TextStyle(color: Colors.grey, fontSize: 14)),
          ],
        ),
      ),
    );
  }

  Widget _buildError() {
    return Expanded(
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.wifi_off_rounded, color: Colors.red, size: 40),
            const SizedBox(height: 12),
            Text('Connection failed: $_error', style: TextStyle(color: Colors.grey[600], fontSize: 13)),
          ],
        ),
      ),
    );
  }

  Widget _buildContent() {
    final myUsername = context.read<UserProvider>().username ?? '';

    return CustomScrollView(
      physics: const BouncingScrollPhysics(),
      slivers: [
        // Live member count banner
        SliverToBoxAdapter(child: _buildCountBanner()),

        // Member grid
        SliverPadding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          sliver: SliverGrid(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.05,
            ),
            delegate: SliverChildBuilderDelegate(
              (_, i) => _MemberCard(member: _members[i], isMe: _members[i].username == myUsername),
              childCount: _members.length,
            ),
          ),
        ),

        // If nobody else is here yet
        if (_members.length <= 1)
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
              child: Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: const Color(0xFF0F1624),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.white.withOpacity(0.06)),
                ),
                child: Column(
                  children: [
                    Text('🧑‍💻', style: const TextStyle(fontSize: 36)),
                    const SizedBox(height: 10),
                    const Text(
                      'You\'re the first one here',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Share this room with friends and focus together.',
                      style: TextStyle(color: Colors.grey[600], fontSize: 12),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
          ),

        const SliverToBoxAdapter(child: SizedBox(height: 40)),
      ],
    );
  }

  Widget _buildCountBanner() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [AppColors.primaryB.withOpacity(0.35), AppColors.primaryA.withOpacity(0.18)],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: AppColors.primaryA.withOpacity(0.25)),
        ),
        child: Row(
          children: [
            Container(
              width: 10,
              height: 10,
              decoration: const BoxDecoration(
                shape: BoxShape.circle,
                color: Color(0xFF10B981),
                boxShadow: [BoxShadow(color: Color(0xFF10B981), blurRadius: 6)],
              ),
            ),
            const SizedBox(width: 10),
            Text(
              '${_members.length} ${_members.length == 1 ? 'person' : 'people'} focusing right now',
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Member card ────────────────────────────────────────────────────────────

class _MemberCard extends StatelessWidget {
  final RoomMember member;
  final bool isMe;
  const _MemberCard({required this.member, required this.isMe});

  @override
  Widget build(BuildContext context) {
    final initial = (member.displayName.isNotEmpty ? member.displayName[0] : member.username[0]).toUpperCase();

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF0F1624),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isMe ? AppColors.primaryA.withOpacity(0.45) : Colors.white.withOpacity(0.07),
          width: isMe ? 1.5 : 1.0,
        ),
        boxShadow: isMe ? [BoxShadow(color: AppColors.primaryA.withOpacity(0.12), blurRadius: 16)] : [],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Avatar
          Stack(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: isMe
                        ? [AppColors.primaryA, AppColors.primaryB]
                        : [const Color(0xFF1E2A40), const Color(0xFF2A3A55)],
                  ),
                  boxShadow: [
                    BoxShadow(color: (isMe ? AppColors.primaryA : Colors.blue).withOpacity(0.25), blurRadius: 10),
                  ],
                ),
                child: Center(
                  child: Text(
                    initial,
                    style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
              ),
              // Online indicator
              Positioned(
                right: 0,
                bottom: 0,
                child: Container(
                  width: 14,
                  height: 14,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFF10B981),
                    border: Border.all(color: const Color(0xFF0F1624), width: 2),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            isMe ? 'You' : member.displayName,
            style: TextStyle(
              color: isMe ? AppColors.primaryA : Colors.white,
              fontSize: 13,
              fontWeight: FontWeight.bold,
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
          if (member.goal != null && member.goal!.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(
              member.goal!,
              style: TextStyle(color: Colors.grey[500], fontSize: 10),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
            ),
          ],
        ],
      ),
    );
  }
}
